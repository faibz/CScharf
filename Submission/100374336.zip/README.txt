To run the examples in the examples directory, the following command can be executed through command prompt:

java -classpath <CScharf.class location> CScharf < <path to example program>

For example, executing the following command from a folder containing both the 'executables' and 'examples' folders will run the the first example program:

java -classpath ./executables CScharf < ./examples/example1.csf

This command can be modified to run the other programs by simply setting the number after 'example' to a number from 1 to 5.