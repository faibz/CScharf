package uk.ac.derby.ldi.CScharf.values;

public enum Modifier {
	CONSTANT,
	READONLY,
	NONE
}