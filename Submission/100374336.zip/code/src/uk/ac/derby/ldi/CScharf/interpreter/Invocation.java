package uk.ac.derby.ldi.CScharf.interpreter;

public interface Invocation {
}
