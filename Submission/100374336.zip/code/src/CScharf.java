/** Convenient runner for the CScharf interpreter. */

public class CScharf {
	public static void main(String[] args) {
		uk.ac.derby.ldi.CScharf.interpreter.Interpreter.main(args);
	}
}
